RCS SEO PACK
Copy the app folder into your Next.js project, merging the new routes/files.
Includes six West Midlands location pages, five service pages, sitemap.ts and robots.ts.
Homepage/layout metadata should be updated separately against the exact current source to avoid overwriting your existing production UI.
